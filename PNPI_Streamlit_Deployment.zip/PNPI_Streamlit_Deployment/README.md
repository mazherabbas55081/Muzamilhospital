# PNPI Streamlit Application

Pak Navy Polytechnic Institute (PNPI) - Mechatronics Engineering web application.

## Features
- Home & Technology Overview
- Course Curriculum & Teachers
- Semester-wise subjects
- Student Result Portal
- Student name and roll-number validation
- PASS/FAIL result calculation

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deployment

This project is ready to deploy on Streamlit Community Cloud. Use `app.py` as the main file.
