import hashlib
from database import get_connection


def _hash_password(password):
    return hashlib.sha256(
        password.encode("utf-8")
    ).hexdigest()


def register_user(name, email, phone, password):
    name = name.strip()
    email = email.strip().lower()
    phone = phone.strip()

    if not name or not email or not password:
        return False, "Name, email and password are required."

    if len(password) < 6:
        return False, "Password must contain at least 6 characters."

    conn = get_connection()

    existing = conn.execute(
        "SELECT id FROM users WHERE email = ?",
        (email,)
    ).fetchone()

    if existing:
        conn.close()
        return False, "An account with this email already exists."

    conn.execute(
        """
        INSERT INTO users (name, email, phone, password, role)
        VALUES (?, ?, ?, ?, 'customer')
        """,
        (
            name,
            email,
            phone,
            _hash_password(password)
        )
    )

    conn.commit()
    conn.close()

    return True, "Registration successful! You can now log in."


def login_user(email, password):
    email = email.strip().lower()

    conn = get_connection()

    row = conn.execute(
        """
        SELECT id, name, email, phone, role
        FROM users
        WHERE email = ? AND password = ?
        """,
        (
            email,
            _hash_password(password)
        )
    ).fetchone()

    conn.close()

    return dict(row) if row else None


def update_user_profile(user_id, name, phone):
    conn = get_connection()

    conn.execute(
        """
        UPDATE users
        SET name = ?, phone = ?
        WHERE id = ?
        """,
        (
            name.strip(),
            phone.strip(),
            user_id
        )
    )

    conn.commit()
    conn.close()
