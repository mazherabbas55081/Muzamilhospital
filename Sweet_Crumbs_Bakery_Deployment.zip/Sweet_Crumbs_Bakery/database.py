import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent / "sweet_crumbs.db"


def get_connection():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT DEFAULT '',
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'customer',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            description TEXT DEFAULT '',
            price REAL NOT NULL,
            stock INTEGER NOT NULL DEFAULT 0,
            image_url TEXT DEFAULT '',
            sales_count INTEGER NOT NULL DEFAULT 0,
            is_today_special INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_code TEXT UNIQUE NOT NULL,
            user_id INTEGER,
            customer_name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT DEFAULT '',
            delivery_address TEXT NOT NULL,
            delivery_type TEXT NOT NULL,
            preferred_date TEXT NOT NULL,
            preferred_time TEXT NOT NULL,
            payment_method TEXT NOT NULL,
            subtotal REAL NOT NULL,
            delivery_fee REAL NOT NULL,
            total_amount REAL NOT NULL,
            special_instructions TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            product_id INTEGER,
            product_name TEXT NOT NULL,
            price REAL NOT NULL,
            quantity INTEGER NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            customer_name TEXT NOT NULL,
            rating INTEGER NOT NULL,
            review TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS contact_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Create a demo admin account if no admin exists.
    admin = cursor.execute(
        "SELECT id FROM users WHERE role = 'admin' LIMIT 1"
    ).fetchone()

    if not admin:
        cursor.execute(
            """
            INSERT INTO users (name, email, phone, password, role)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                "Sweet Crumbs Admin",
                "admin@sweetcrumbs.com",
                "+92 300 1234567",
                "admin123",
                "admin"
            )
        )

    # Add starter products only when the catalog is empty.
    product_count = cursor.execute(
        "SELECT COUNT(*) AS total FROM products"
    ).fetchone()["total"]

    if product_count == 0:
        products = [
            (
                "Belgian Chocolate Cake",
                "Cakes 🎂",
                "Rich chocolate sponge with Belgian chocolate ganache.",
                2800,
                15,
                "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=900&q=80",
                35,
                1
            ),
            (
                "Red Velvet Cake",
                "Cakes 🎂",
                "Soft red velvet layers with smooth cream cheese frosting.",
                2600,
                12,
                "https://images.unsplash.com/photo-1586788680434-30d324b2d46f?auto=format&fit=crop&w=900&q=80",
                28,
                1
            ),
            (
                "Strawberry Cupcakes",
                "Cupcakes 🧁",
                "Fluffy vanilla cupcakes topped with strawberry cream.",
                750,
                30,
                "https://images.unsplash.com/photo-1576618148400-f54bed99fcfd?auto=format&fit=crop&w=900&q=80",
                45,
                0
            ),
            (
                "Butter Croissant",
                "Pastries 🥐",
                "Crispy, flaky and buttery French-style croissant.",
                350,
                40,
                "https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=900&q=80",
                60,
                0
            ),
            (
                "Glazed Donuts",
                "Donuts 🍩",
                "Fresh soft donuts finished with a sweet glaze.",
                450,
                35,
                "https://images.unsplash.com/photo-1551024506-0bccd828d307?auto=format&fit=crop&w=900&q=80",
                55,
                0
            ),
            (
                "Chocolate Chip Cookies",
                "Cookies 🍪",
                "Crunchy edges with a soft chocolate-chip center.",
                550,
                25,
                "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=900&q=80",
                50,
                0
            ),
            (
                "Cinnamon Buns",
                "Bread & Buns 🍞",
                "Warm cinnamon rolls with a delicious sweet glaze.",
                650,
                20,
                "https://images.unsplash.com/photo-1509365465985-25d11c17e812?auto=format&fit=crop&w=900&q=80",
                38,
                0
            ),
            (
                "Lotus Biscoff Dessert",
                "Desserts 🍮",
                "Creamy layered dessert with Lotus Biscoff crumbs.",
                900,
                18,
                "https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=900&q=80",
                42,
                1
            ),
            (
                "Birthday Celebration Cake",
                "Birthday Cakes 🎉",
                "Customizable celebration cake for birthdays and events.",
                3200,
                10,
                "https://images.unsplash.com/photo-1535141192574-5d4897c12636?auto=format&fit=crop&w=900&q=80",
                25,
                0
            )
        ]

        cursor.executemany(
            """
            INSERT INTO products (
                name, category, description, price, stock,
                image_url, sales_count, is_today_special
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            products
        )

    conn.commit()
    conn.close()


def get_all_users():
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM users ORDER BY id DESC"
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]
