# 🍰 Sweet Crumbs Bakery

A professional bakery ordering web application built with Python and Streamlit.

## Features

- 🏠 Bakery home page
- 🧁 Product menu and search
- 🔎 Category and price filters
- 💰 Product sorting
- 🛒 Shopping cart
- 📦 Home delivery / store pickup
- 🎂 Custom cake designer
- 👤 Customer registration and login
- 📋 Customer order history
- ⭐ Reviews and ratings
- 📞 Contact page
- 👨‍💼 Admin dashboard
- 📊 Sales and inventory charts
- 🧾 Order status management
- 🧁 Admin product creation
- 💾 SQLite database

## Files

```text
Sweet_Crumbs_Bakery/
├── app.py
├── database.py
├── auth.py
├── utils.py
├── requirements.txt
└── README.md
```

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Demo Admin Login

- Email: `admin@sweetcrumbs.com`
- Password: `admin123`

Change the demo admin password before using the app for real customers.

## Deployment

Upload all project files to your GitHub repository and deploy `app.py` using Streamlit Community Cloud.

The SQLite database file is created automatically when the app starts. For a production deployment, use a hosted database instead of local SQLite if persistent multi-instance storage is required.
