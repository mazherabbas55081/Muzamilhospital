import streamlit as st


def apply_custom_css():
    st.markdown(
        """
        <style>
        .stApp {
            background: linear-gradient(
                135deg,
                #fff8f0 0%,
                #fffaf5 45%,
                #f8efe6 100%
            );
        }

        .hero-box {
            padding: 45px 30px;
            border-radius: 22px;
            text-align: center;
            margin-bottom: 25px;
            background: linear-gradient(
                135deg,
                #f9e4d4,
                #fff7ef
            );
            border: 1px solid #ead5c1;
        }

        .main-header {
            color: #5C3A21;
            font-weight: 800;
        }

        .product-card {
            background: white;
            padding: 14px;
            margin-bottom: 20px;
            border-radius: 16px;
            border: 1px solid #eadfd5;
            box-shadow: 0 5px 18px rgba(92, 58, 33, 0.08);
            min-height: 355px;
        }

        .stButton > button {
            border-radius: 10px;
            font-weight: 600;
        }

        [data-testid="stSidebar"] {
            background: #fff1e5;
        }
        </style>
        """,
        unsafe_allow_html=True
    )


def init_session():
    if "user" not in st.session_state:
        st.session_state.user = None

    if "cart" not in st.session_state:
        st.session_state.cart = {}


def add_to_cart(item_id, name, price, stock):
    if "cart" not in st.session_state:
        st.session_state.cart = {}

    if item_id in st.session_state.cart:
        current_qty = st.session_state.cart[item_id]["quantity"]

        if current_qty < stock:
            st.session_state.cart[item_id]["quantity"] += 1
        else:
            st.warning("You have reached the available stock.")
    else:
        st.session_state.cart[item_id] = {
            "name": name,
            "price": float(price),
            "stock": int(stock),
            "quantity": 1
        }
